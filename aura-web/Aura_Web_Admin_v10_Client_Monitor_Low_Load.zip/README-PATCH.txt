Aura Web Admin v10 — Client Monitor (Low-Load)
================================================

What changed
------------
- New /admin/clients page inspired by client-monitor dashboards.
- Shows current Wi-Fi connected count from the AP.
- Shows currently AUTHORIZED voucher clients from Omada hotspot sessions.
- Each authorized client card includes device name, MAC/IP, SSID, voucher code,
  remaining voucher time, start time, download and upload usage.
- Recent voucher session table includes VALID / EXPIRED status and expiration.
- Vouchers page now shows which device used a voucher when Omada has a session record.
- Overview now shows AUTHORIZED NOW and links directly to Clients.
- Desktop and mobile navigation now include Clients.
- Same Aura v9/v10 visual language is retained for aura.local / customer status.

Low-RAM design
--------------
This does NOT add a background daemon, WebSocket, auto polling, or another Omada API
request. The Clients page reuses the SAME hotspot-client response already fetched by
v9 for voucher status sync and keeps only a small prepared cache for up to 15 seconds.
The live countdown on client cards happens only in the browser with JavaScript.

Important limitation
--------------------
The currently verified Omada endpoint gives voucher/hotspot session details. It does
not give us verified identity/details for unauthenticated/pending Wi-Fi devices.
Therefore v10 shows an "Other connected" count but does not invent pending-device
names or add unverified Omada endpoints. We can add pending-device details later only
after safely verifying the exact API path on this Omada 5.15 controller.

Files to deploy
---------------
aura-web/app.py
aura-web/static/style.css
aura-web/templates/admin_base.html
aura-web/templates/dashboard.html
aura-web/templates/vouchers.html
aura-web/templates/clients.html

Orange Pi deployment
---------------------
cd /root/aura-voucher-wifi
git pull origin web-admin-v1

cp aura-web/app.py /opt/aura-voucher-wifi/aura-web/app.py
cp aura-web/static/style.css /opt/aura-voucher-wifi/aura-web/static/style.css
cp aura-web/templates/admin_base.html /opt/aura-voucher-wifi/aura-web/templates/admin_base.html
cp aura-web/templates/dashboard.html /opt/aura-voucher-wifi/aura-web/templates/dashboard.html
cp aura-web/templates/vouchers.html /opt/aura-voucher-wifi/aura-web/templates/vouchers.html
cp aura-web/templates/clients.html /opt/aura-voucher-wifi/aura-web/templates/clients.html

/opt/aura-voucher-wifi/.venv/bin/python -m py_compile /opt/aura-voucher-wifi/aura-web/app.py
systemctl restart aura-web
systemctl is-active aura-web

Open:
http://192.168.1.124/admin/clients
